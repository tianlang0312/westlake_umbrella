// 第二幕 · 制伞：六步工序交互（选竹→削骨→组装→绷绸→绘纹→收饰）
import { UmbrellaScene } from '../umbrella.js';
import { store, texCtx, artCtx, drawTexture, clearArtwork } from '../store.js';
import { playClick, playOpen } from '../audio.js';

let umb = null, cur = 0, bound = false;
let brushMode = 'pen', brushSize = 8, curColor = '#334a48', hasStrokes = false;
const STEP_NAMES = ['选竹', '削骨', '组装', '绷绸', '绘纹', '收饰'];
const STEP_KEYS = ['zhu', 'gu', 'zhuang', 'hu', 'hui', 'you'];
const EGGS = {
  zhu: '🎋 西湖绸伞以淡竹为骨，选竹讲究韧性与匀称。',
  gu: '🦴 真正的西湖绸伞需精细加工多根竹骨。本互动采用 16 根骨架来直观演示开合结构。',
  zhuang: '🔧 西湖绸伞的一大特色是套合技艺，合伞时竹骨可有序收拢。',
  hu: '🧵 绸面先裁剪、绷紧，再与竹骨结合。绸料轻盈，适合传统装饰技法。',
  hui: '🎨 绸伞常用刷花、彩绘、刺绣装饰；山水花鸟，也能化作你自己的图案。',
  you: '🌸 绸面装饰完成后，再修饰伞边与细节。此处使用光泽变化来模拟丝绸的视觉质感。',
};

export function enterMake() {
  drawTexture();
  if (!umb) {
    umb = new UmbrellaScene(document.getElementById('makeCanvas'));
    umb.bindDrag();
  }
  umb.start();
  if (!bound) {
    bound = true;
    document.getElementById('stepPrev').onclick = () => go(cur - 1, true);
    document.getElementById('stepNext').onclick = () => go(cur + 1);
  }
  go(firstUndone());
}

export function leaveMake() { umb && umb.stop(); }

function firstUndone() {
  const i = STEP_KEYS.findIndex(k => !store.stepsDone[k]);
  return i === -1 ? 5 : i;
}

// 把右侧三维伞还原成"第 i 步刚开始"的样子
function applyStepVisual(i) {
  if (!umb) return;
  umb.setCanopyOpacity(1);
  if (i <= 2) {
    // 选竹 / 削骨 / 组装：只有骨架，无伞面
    umb.setCanopyVisible(false);
    umb.setOiled(false);
    umb.setRibCount([0, 4, 16][i]);
    umb.setOpenness(.2, true);
  } else if (i === 3) {
    // 绷绸起点：骨架已张开，伞面尚未绷上
    umb.setCanopyVisible(false);
    umb.setOiled(false);
    umb.setRibCount(16);
    umb.setOpenness(.6, true);
  } else {
    // 绘纹 / 收饰：伞面可见，收饰前仍是哑光
    umb.setCanopyVisible(true);
    umb.setRibCount(16);
    umb.setOiled(i === 5 ? false : store.stepsDone.you);
    umb.setOpenness(.6, true);
  }
  drawTexture();
}

function go(n, back = false) {
  const prev = cur;
  cur = Math.max(0, Math.min(5, n));
  // 回退时把当前步及之后的所有步骤状态清空，左侧进度与右侧伞同时回退
  if (back && cur < prev) {
    for (let k = cur; k < STEP_KEYS.length; k++) store.stepsDone[STEP_KEYS[k]] = false;
  }
  renderProgress();
  renderStep();
  updateNav();
  applyStepVisual(cur);
  const egg = document.getElementById('knowledgeEgg');
  egg.classList.remove('hidden');
  egg.textContent = EGGS[STEP_KEYS[cur]];
}

function renderProgress() {
  document.getElementById('stepProgress').innerHTML = STEP_NAMES.map((n, i) =>
    `<span class="sp ${store.stepsDone[STEP_KEYS[i]] ? 'done' : i === cur ? 'cur' : ''}">${i + 1} ${n}${store.stepsDone[STEP_KEYS[i]] ? ' ✓' : ''}</span>`
  ).join('');
}

function updateNav() {
  document.getElementById('stepPrev').disabled = cur === 0;
  const done = store.stepsDone[STEP_KEYS[cur]];
  const next = document.getElementById('stepNext');
  next.disabled = !done;
  next.textContent = cur === 5 ? '去撑伞 →' : '下一步 →';
  if (cur === 5) next.onclick = () => { location.hash = '#/play'; };
  else next.onclick = () => go(cur + 1);
}

function done(key) {
  store.stepsDone[key] = true;
  playClick();
  renderProgress();
  updateNav();
}

function renderStep() {
  const body = document.getElementById('stepBody');
  const key = STEP_KEYS[cur];
  if (key === 'zhu') renderZhu(body);
  else if (key === 'gu') renderGu(body);
  else if (key === 'zhuang') renderZhuang(body);
  else if (key === 'hu') renderHu(body);
  else if (key === 'hui') renderHui(body);
  else renderYou(body);
}

/* ---- 1 选竹 ---- */
function renderZhu(body) {
  body.innerHTML = `
    <h3>第一步 · 选竹</h3>
    <p class="step-desc">点击挑选一段适宜制作竹骨的淡竹。竹材均匀，收放才能顺畅。</p>
    <div class="bamboo-row">
      <button class="bamboo-card" data-ok="0">🎋<br>一年嫩竹<br><small>太软</small></button>
      <button class="bamboo-card" data-ok="1">🎋<br>适龄淡竹<br><small>坚韧适中</small></button>
      <button class="bamboo-card" data-ok="0">🎋<br>老化竹材<br><small>太脆</small></button>
    </div>
    <p class="step-desc" id="zhuMsg">匠人经验：淡竹质地与弧度，会影响竹骨的强度与收合效果。</p>`;
  body.querySelectorAll('.bamboo-card').forEach(c => {
    c.onclick = () => {
      if (c.dataset.ok === '1') {
        c.classList.add('good');
        document.getElementById('zhuMsg').textContent = '选竹完成！可以开始制作骨架了。';
        umb.setRibCount(4); // 先出几根骨示意
        done('zhu');
      } else {
        c.classList.add('bad');
        document.getElementById('zhuMsg').textContent = '这段竹材不太适合制骨，请重新选择。';
      }
    };
  });
}

/* ---- 2 削骨 ---- */
function renderGu(body) {
  body.innerHTML = `
    <h3>第二步 · 削骨</h3>
    <p class="step-desc">在竹面上<strong>按住并左右拖动</strong>，把骨条打磨出弧度。竹屑纷飞中，伞骨渐成。</p>
    <div class="rub-zone" id="rubZone"></div>
    <div class="progress-bar"><i id="rubBar"></i></div>
    <p class="step-desc" id="guMsg">打磨进度 0%</p>`;
  const zone = body.querySelector('#rubZone');
  let prog = 0, lastX = null, active = false;
  zone.addEventListener('pointerdown', e => { active = true; lastX = e.clientX; try { zone.setPointerCapture(e.pointerId); } catch (_) { } });
  zone.addEventListener('pointerup', () => { active = false; lastX = null; });
  zone.addEventListener('pointermove', e => {
    if (!active || lastX === null) return;
    prog = Math.min(100, prog + Math.abs(e.clientX - lastX) * .35);
    lastX = e.clientX;
    body.querySelector('#rubBar').style.width = prog + '%';
    body.querySelector('#guMsg').textContent = '打磨进度 ' + Math.round(prog) + '%';
    umb.setRibCount(Math.max(4, Math.round(prog / 100 * 16)));
    if (prog >= 100) {
      body.querySelector('#guMsg').textContent = '演示骨架就位，下一步开始组装！';
      done('gu');
    }
  });
}

/* ---- 3 组装 ---- */
function renderZhuang(body) {
  body.innerHTML = `
    <h3>第三步 · 组装</h3>
    <p class="step-desc">连续点击"卡入伞骨"，看骨架从收拢到张开。</p>
    <button class="btn-primary" id="assembleBtn">卡入一组伞骨</button>
    <div class="progress-bar"><i id="asmBar"></i></div>
    <p class="step-desc" id="asmMsg">已组装 0 / 4 组</p>`;
  let n = 0;
  body.querySelector('#assembleBtn').onclick = () => {
    n = Math.min(4, n + 1);
    umb.targetOpen = .2 + n * .1;
    umb.open();
    umb.targetOpen = .2 + n * .1;
    body.querySelector('#asmBar').style.width = n * 25 + '%';
    body.querySelector('#asmMsg').textContent = `已组装 ${n} / 4 组`;
    playClick();
    if (n >= 4) {
      body.querySelector('#asmMsg').textContent = '骨架张开！机关锁扣"咔哒"一声就位。';
      playOpen();
      done('zhuang');
    }
  };
}

/* ---- 4 糊面 ---- */
function renderHu(body) {
  body.innerHTML = `
    <h3>第四步 · 绷绸</h3>
    <p class="step-desc"><strong>长按</strong>下方按钮，模拟把绸面绷紧并与伞骨结合。丝绸服帖，张弛有度。</p>
    <button class="btn-primary hold-btn" id="holdHu"><span class="fill"></span><span style="position:relative">长按绷绸</span></button>
    <div class="progress-bar"><i id="huBar"></i></div>`;
  bindHold(body.querySelector('#holdHu'), p => {
    body.querySelector('#huBar').style.width = p * 100 + '%';
    umb.setCanopyVisible(true);
    umb.setCanopyOpacity(p);
  }, () => {
    umb.setCanopyOpacity(1);
    done('hu');
  });
}

/* ---- 5 绘纹 ---- */
const THEMES = {
  shanshui: { name: '西湖山水', fn: drawShanshui },
  hehua: { name: '荷花', fn: drawHehua },
  huaniao: { name: '花鸟', fn: drawHuaniao },
  yanyu: { name: '烟雨', fn: drawYanyu },
};
let curTheme = 'shanshui';

function renderHui(body) {
  body.innerHTML = `
    <h3>第五步 · 绘伞成韵</h3>
    <p class="step-desc">选一套纹样元素，或自己提笔；图案实时映射到右侧伞面。</p>
    <div class="pattern-lib">${Object.entries(THEMES).map(([k, v]) =>
    `<button class="pattern-item ${k === curTheme ? 'active' : ''}" data-t="${k}">${v.name}</button>`).join('')}
    </div>
    <div class="field"><label>配色</label><div class="color-row" id="colorRow"></div></div>
    <div class="brush-toolbar">
      <button class="tool-btn active" data-tool="pen">✏️ 画笔</button>
      <button class="tool-btn" data-tool="eraser">🩹 橡皮擦</button>
      <button class="tool-btn" id="clearArt">🗑 清除</button>
    </div>
    <div class="field"><label>画笔粗细 <b id="bsv">8</b></label><input type="range" id="brushSize" min="2" max="40" value="8"></div>
    <div class="field"><label>提笔绘制（在下方纸面拖动）</label><canvas class="draw-pad" id="drawPad" width="512" height="512"></canvas></div>
    <details class="field"><summary style="cursor:pointer;font-size:13px">📷 也可以上传照片，AI 国风化处理</summary>
      <div class="field"><input type="file" id="huiUpload" accept="image/png,image/jpeg,image/webp,image/bmp"></div>
      <div class="field"><label>艺术效果</label><select id="huiStyle">
        <option value="ink">空灵水墨（推荐）</option><option value="gongbi">工笔淡染</option><option value="pastel">江南淡彩</option>
      </select></div>
      <p class="step-desc">推荐使用“空灵水墨”或“江南淡彩”，整体会更接近浅墨山水、留白充足的国风效果。</p>
      <button class="btn-primary" id="huiConvert">生成并映射到伞面</button>
      <p class="step-desc" id="huiMsg"></p>
    </details>`;

  // 配色：既是画笔颜色；若伞面还没有手绘笔迹，也会重绘当前纹样的配色
  const colors = ['#334a48', '#86a59a', '#d8a6a1', '#c9a063', '#5d4037', '#2e4057'];
  const row = body.querySelector('#colorRow');
  colors.forEach(c => {
    const d = document.createElement('span');
    d.className = 'color-dot' + (c === curColor ? ' active' : '');
    d.style.background = c;
    d.onclick = () => {
      curColor = c;
      row.querySelectorAll('.color-dot').forEach(x => x.classList.remove('active'));
      d.classList.add('active');
      if (!hasStrokes) {
        THEMES[curTheme].fn(curColor);
        redrawPad();
      } else if (window.toast) {
        window.toast('已切换画笔颜色；重新选择纹样可同时改纹样配色');
      }
    };
    row.appendChild(d);
  });

  // 纹样元素：点击后重新生成整幅纹样
  body.querySelectorAll('.pattern-item').forEach(b => {
    b.onclick = () => {
      curTheme = b.dataset.t;
      body.querySelectorAll('.pattern-item').forEach(x => x.classList.remove('active'));
      b.classList.add('active');
      hasStrokes = false;
      THEMES[curTheme].fn(curColor);
      redrawPad();
    };
  });

  // 画笔工具：画笔 / 橡皮擦 / 清除
  body.querySelectorAll('.tool-btn[data-tool]').forEach(b => {
    b.onclick = () => {
      brushMode = b.dataset.tool;
      body.querySelectorAll('.tool-btn[data-tool]').forEach(x => x.classList.remove('active'));
      b.classList.add('active');
      playClick();
    };
  });
  const sizeInput = body.querySelector('#brushSize');
  sizeInput.oninput = () => {
    brushSize = +sizeInput.value;
    body.querySelector('#bsv').textContent = brushSize;
  };
  brushSize = +sizeInput.value;
  body.querySelector('#clearArt').onclick = () => {
    playClick();
    hasStrokes = false;
    clearArtwork();
    redrawPad();
    if (window.toast) window.toast('已清除伞面上的绘纹');
  };

  // 画板：所有笔迹只写入用户创作层，因此翻页/切换环节都不会丢失
  const pad = body.querySelector('#drawPad');
  redrawPad();
  let drawing = false, last = null;
  let pending = false;
  const pos = e => {
    const r = pad.getBoundingClientRect();
    return [(e.clientX - r.left) / r.width * 1024, (e.clientY - r.top) / r.height * 1024];
  };
  // 每帧最多重绘一次贴图，保证拖动画笔时流畅
  function scheduleTexture() {
    if (pending) return;
    pending = true;
    requestAnimationFrame(() => {
      pending = false;
      drawTexture();
      redrawPad();
    });
  }
  function paint(from, to) {
    artCtx.save();
    artCtx.beginPath();
    artCtx.arc(512, 512, 490, 0, Math.PI * 2);
    artCtx.clip();
    const erasing = brushMode === 'eraser';
    artCtx.globalCompositeOperation = erasing ? 'destination-out' : 'source-over';
    artCtx.strokeStyle = erasing ? '#000' : curColor;
    artCtx.fillStyle = erasing ? '#000' : curColor;
    artCtx.lineWidth = brushSize * 2;
    artCtx.lineCap = 'round';
    artCtx.lineJoin = 'round';
    if (from && (from[0] !== to[0] || from[1] !== to[1])) {
      artCtx.beginPath();
      artCtx.moveTo(from[0], from[1]);
      artCtx.lineTo(to[0], to[1]);
      artCtx.stroke();
    } else {
      artCtx.beginPath();
      artCtx.arc(to[0], to[1], brushSize, 0, Math.PI * 2);
      artCtx.fill();
    }
    artCtx.restore();
    if (!erasing) hasStrokes = true;
    scheduleTexture();
  }
  pad.addEventListener('pointerdown', e => {
    drawing = true;
    try { pad.setPointerCapture(e.pointerId); } catch (_) { }
    last = pos(e);
    paint(last, last);
  });
  pad.addEventListener('pointerup', () => { drawing = false; last = null; });
  pad.addEventListener('pointercancel', () => { drawing = false; last = null; });
  pad.addEventListener('pointermove', e => {
    if (!drawing) return;
    const p = pos(e);
    paint(last, p);
    last = p;
  });

  // 上传 AI 风格化（沿用原后端接口）
  body.querySelector('#huiConvert').onclick = async () => {
    const f = body.querySelector('#huiUpload').files[0];
    const msg = body.querySelector('#huiMsg');
    if (!f) { msg.textContent = '请先选择图片'; return; }
    const data = new FormData();
    data.append('image', f); data.append('style', body.querySelector('#huiStyle').value);
    msg.textContent = '正在进行国风图像处理……';
    try {
      const r = await fetch('/api/stylize', { method: 'POST', body: data });
      const res = await r.json();
      if (!r.ok) throw Error(res.error || '处理失败');
      const img = new Image();
      img.onload = () => { store.patternImg = img; drawTexture(); redrawPad(); msg.textContent = '已映射到伞面！'; };
      img.src = res.image;
    } catch (e) { msg.textContent = '错误：' + e.message; }
  };

  if (!store.stepsDone.hui) done('hui'); // 进入绘纹即视为可继续（纹样可选）
}

function redrawPad() {
  const pad = document.getElementById('drawPad');
  if (!pad) return;
  pad.getContext('2d').drawImage(texCtx.canvas, 0, 0, 512, 512);
}

/* 主题纹样绘制：只画在用户创作层，绘制完由 drawTexture 统一合成 */
function themeBase(color) {
  // 选择新纹样时，先清掉上一次纹样与手绘笔迹
  artCtx.clearRect(0, 0, 1024, 1024);
  store.patternImg = null;
  artCtx.save();
  artCtx.beginPath();
  artCtx.arc(512, 512, 490, 0, Math.PI * 2);
  artCtx.clip();
  artCtx.globalAlpha = 1;
  artCtx.strokeStyle = artCtx.fillStyle = color;
  return artCtx;
}
function themeEnd() {
  artCtx.restore();
  drawTexture();
}

function drawShanshui(color) {
  const c = themeBase(color);
  c.lineWidth = 6;
  // 远山
  c.globalAlpha = .25;
  for (let k = 0; k < 3; k++) {
    c.beginPath();
    for (let x = 60; x <= 964; x += 4) {
      const y = 700 - k * 90 - Math.abs(Math.sin(x * .008 + k * 2)) * 130;
      x === 60 ? c.moveTo(x, y) : c.lineTo(x, y);
    }
    c.stroke();
  }
  // 近山
  c.globalAlpha = .8;
  c.beginPath();
  for (let x = 60; x <= 964; x += 4) {
    const y = 760 - Math.abs(Math.sin(x * .006)) * 190;
    x === 60 ? c.moveTo(x, y) : c.lineTo(x, y);
  }
  c.stroke();
  // 日
  c.globalAlpha = .9;
  c.beginPath(); c.arc(700, 300, 55, 0, Math.PI * 2); c.stroke();
  // 扁舟
  c.globalAlpha = .7;
  c.beginPath(); c.moveTo(360, 820); c.quadraticCurveTo(430, 850, 500, 820); c.stroke();
  c.beginPath(); c.moveTo(430, 820); c.lineTo(430, 770); c.stroke();
  c.globalAlpha = 1;
  themeEnd();
}

function drawHehua(color) {
  const c = themeBase(color);
  // 荷花两朵
  for (const [cx, cy, s] of [[350, 420, 1], [660, 620, .8]]) {
    for (let p = 0; p < 8; p++) {
      const a = p * Math.PI / 4;
      c.save(); c.translate(cx, cy); c.rotate(a); c.scale(s, s);
      c.globalAlpha = .75;
      c.beginPath(); c.ellipse(0, -46, 20, 48, 0, 0, Math.PI * 2); c.stroke();
      c.restore();
    }
    c.globalAlpha = .9;
    c.beginPath(); c.arc(cx, cy, 16 * s, 0, Math.PI * 2); c.fill();
  }
  // 荷叶
  c.globalAlpha = .3;
  for (const [cx, cy, r] of [[600, 380, 90], [330, 660, 110], [700, 760, 80]]) {
    c.beginPath(); c.arc(cx, cy, r, .3, Math.PI * 1.7); c.stroke();
  }
  c.globalAlpha = 1;
  themeEnd();
}

function drawHuaniao(color) {
  const c = themeBase(color);
  c.lineWidth = 5;
  // 梅枝
  c.beginPath(); c.moveTo(180, 850); c.quadraticCurveTo(420, 560, 700, 430); c.stroke();
  c.beginPath(); c.moveTo(430, 620); c.quadraticCurveTo(560, 560, 640, 600); c.stroke();
  // 花
  for (const [x, y] of [[380, 640], [500, 560], [620, 480], [560, 600], [680, 560], [300, 730]]) {
    for (let p = 0; p < 5; p++) {
      const a = p * Math.PI * 2 / 5;
      c.beginPath(); c.arc(x + Math.cos(a) * 13, y + Math.sin(a) * 13, 10, 0, Math.PI * 2); c.stroke();
    }
    c.beginPath(); c.arc(x, y, 5, 0, Math.PI * 2); c.fill();
  }
  // 鸟
  c.lineWidth = 4;
  c.beginPath(); c.moveTo(720, 350); c.quadraticCurveTo(760, 320, 760, 360); c.quadraticCurveTo(790, 330, 820, 350); c.stroke();
  c.beginPath(); c.moveTo(640, 280); c.quadraticCurveTo(672, 256, 672, 288); c.quadraticCurveTo(696, 262, 720, 280); c.stroke();
  themeEnd();
}

function drawYanyu(color) {
  const c = themeBase(color);
  // 雨丝
  c.lineWidth = 3; c.globalAlpha = .5;
  for (let i = 0; i < 90; i++) {
    const x = Math.random() * 1024, y = Math.random() * 1024, l = 20 + Math.random() * 40;
    c.beginPath(); c.moveTo(x, y); c.lineTo(x - l * .25, y + l); c.stroke();
  }
  // 湖面涟漪
  c.globalAlpha = .6; c.lineWidth = 4;
  for (const [cx, cy] of [[350, 700], [650, 780], [512, 850]]) {
    for (let r = 20; r < 90; r += 24) {
      c.beginPath(); c.ellipse(cx, cy, r, r * .32, 0, 0, Math.PI * 2); c.stroke();
    }
  }
  c.globalAlpha = 1;
  themeEnd();
}

/* ---- 6 刷油 ---- */
function renderYou(body) {
  body.innerHTML = `
    <h3>第六步 · 收饰</h3>
    <p class="step-desc"><strong>长按</strong>完成伞边与光泽的最后修饰，让绸面呈现柔和丝光。</p>
    <button class="btn-primary hold-btn" id="holdYou"><span class="fill"></span><span style="position:relative">长按收饰</span></button>
    <div class="progress-bar"><i id="youBar"></i></div>`;
  bindHold(body.querySelector('#holdYou'), p => {
    body.querySelector('#youBar').style.width = p * 100 + '%';
    umb.canopyMat.roughness = .95 - p * .6;
  }, () => {
    umb.setOiled(true);
    done('you');
  });
}

// 长按进度工具
function bindHold(btn, onProgress, onDone) {
  let raf = null, t0 = 0;
  const DUR = 1400;
  const fill = btn.querySelector('.fill');
  function tick() {
    const p = Math.min(1, (performance.now() - t0) / DUR);
    fill.style.width = p * 100 + '%';
    onProgress(p);
    if (p >= 1) { onDone(); return; }
    raf = requestAnimationFrame(tick);
  }
  btn.addEventListener('pointerdown', () => { t0 = performance.now(); tick(); });
  const cancel = () => { cancelAnimationFrame(raf); };
  btn.addEventListener('pointerup', cancel);
  btn.addEventListener('pointerleave', cancel);
}
